package com.wexberry.popupwindow

data class ItemList(
    val image: Int,
    val name: String,
    val defColorText: Int,
    val selectColorText: Int,
    val defColorBackground: Int,
    val selectColorBackground: Int,
    val icon: Int
)


